/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   prs_util.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyeonwch <hyeonwch@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/14 14:10:52 by hyeonwch          #+#    #+#             */
/*   Updated: 2024/07/14 14:11:41 by hyeonwch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "tksh.h"
#include "tksh_parse.h"
#include "libft.h"
#include <stdio.h>

t_bool	prs_is_pipe(char *c)
{
	return (PRS_PIPE == *c);
}

t_bool	prs_is_end_of_str(char *str)
{
	return (*str == '\0');
}

t_bool	prs_is_equal(char *c)
{
	return ('=' == *c);
}

t_bool	prs_is_white_space(char *c)
{
	if (!*c)
		return (FALSE);
	return (ft_strchr(PRS_WHITE_SPACE, *c) != NULL);
}

t_bool	prs_is_variable(char *c)
{
	return (*c == PRS_VARIABLE);
}
