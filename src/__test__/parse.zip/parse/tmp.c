#include "tksh.h"
#include "tksh_parse.h"
#include "libft.h"
#include <stdio.h>

// parser
void	prs_init_stack_token_lists(t_prs_stack ***stack_list,
		t_token ***token_list, char *usr_input, char ***envp);
t_token	**prs_parse(char *usr_input, char ***envp);

// tstack and token init
t_token	**prs_init_token_list(size_t size, char ***envp);
void	prs_init_token(t_token **token, char	***envp);
t_prs_stack	**prs_init_stack_list(char *ori_str, char ***envp);
void	prs_stack_init(t_prs_stack	**stack, char *ori_str, char ***envp);
void	init_free(t_prs_stack **stack, char *ori_str, char ***envp);

// argv_list utils
t_argv_list	*prs_argv_list_new_node(char *str);
void	prs_argv_list_add_node(
			char *str, t_prs_stack *stack);
char	*prs_argv_list_get_str(t_argv_list *argv_list);
t_argv_list	*prs_argv_list_find_last(t_argv_list **start);
size_t	prs_argv_list_count(t_argv_list **start);

// make file_list utils
t_file_list	*prs_create_file_list(char *file_name, t_file_type type,
				void *limiter, t_bool expand);
t_file_list	*prs_file_list_find_last(t_file_list **start);
void	prs_file_list_add_node(t_file_list *new, t_file_list **head);
void	prs_file_check_and_add_node(
	char *file_name, t_prs_stack *stack, t_token *token, t_file_type type);

// 파싱한거 토큰에 넣기
void	*prs_set_token(t_prs_stack *stack, t_token *token);
void	prs_set_cmd_path_in_token(t_token *token);
void	prs_set_argv_into_token(
			t_token *token, t_prs_stack *stack);
void	prs_set_file_path_in_token(t_token *token, t_prs_stack *stack);
void	prs_set_heredoc_path(t_token **token);

// resource clean - stack
void	prs_free_stack_list(t_prs_stack **stack_list);
void	prs_free_stack(t_prs_stack *stack);
void	prs_free_arg_list(t_argv_list **start);

// resource clean - token
void	tksh_free_token_list(t_token **token_list);
void	tksh_free_token(t_token *token);
void	prs_free_file_list(t_file_list **file);

// free - err
void	*prs_err_free_all(char *usr_input,
		t_prs_stack **stack_list, t_token **token_list);

// make str
char	*prs_make_argv_str(t_prs_stack *stack);
char	*prs_extract_var_by_split(char **result, t_prs_stack *stack);
void	prs_finalize_result(char *result,
		t_prs_stack *stack);
char	*prs_handle_whitespace(t_prs_stack *stack,
		char *tmp, char *result);

// process input
char	*prs_process_stack(t_prs_stack *stack,
		t_token *token, char *result);
char	*prs_process_quote(t_prs_stack *stack);
void	prs_process_redir(t_token *token,
		t_prs_stack *stack, char **result);

// file setting
void	prs_setting_file(
	t_token *token, t_prs_stack *stack,
	t_bool (*judge_file_type)(char *str), t_file_type type);
size_t	prs_skip_redir_and_whitespace(t_prs_stack *stack);
char	*prs_process_quote_or_variable(
	t_prs_stack *stack, char *result, char **start);
char	*prs_find_file_name(t_prs_stack *stack);
char	*prs_finalize_file_result(t_prs_stack *stack, char *result, char *start);

// process heredoc
void	prs_set_heredoc_file(t_token *token, t_prs_stack *stack,
			t_file_type type);
char	*prs_make_heredoc_file(int count);
char	*prs_remove_quote_in_heredoc(t_prs_stack *stack);
void	prs_skip_for_heredoc_limiter(t_prs_stack *stack, char **start);
char	*prs_find_heredoc_limiter(t_prs_stack *stack, t_bool *flag);

// process redir utils
t_bool	prs_is_redir(char *c);
t_bool	prs_is_in_file(char *c);
t_bool	prs_is_out_file(char *c);
t_bool	prs_is_append(char *c);
t_bool	prs_is_heredoc(char *c);

// err check
void	*handle_unbalanced_quote(char *result);
void	prs_redir_err(t_prs_stack *stack);
t_bool	is_check_err_in_stack(t_prs_stack *stack);

// process qoute utils
t_bool	prs_is_double_quote(char *c);
t_bool	prs_is_single_quote(char *c);
t_bool	prs_is_quote(char *c);
t_bool	prs_is_balanced_quote(char *start);
void	prs_skip_qoute(char **ori_str);

// process qoute
static void	prs_process_judge_qoute(t_prs_stack *stack, char *start);
void	prs_process_single_qoute(t_prs_stack *stack, char **result);
void	prs_process_double_qoute(t_prs_stack *stack, char **result);
char	*prs_remove_quote(t_prs_stack *stack);

// stack utils
t_bool	prs_stack_is_empty(t_prs_stack *stack);
t_bool	prs_stack_is_full(t_prs_stack *stack);
void	prs_stack_push(t_prs_stack *stack, char elem);
char	prs_stack_pop(t_prs_stack *stack);
char	prs_stack_pick(t_prs_stack *stack);

// parse utils
t_bool	prs_is_pipe(char *c);
t_bool	prs_is_end_of_str(char *str);
t_bool	prs_is_equal(char *c);
t_bool	prs_is_white_space(char *c);
t_bool	prs_is_end_of_name(char *str);

// variable utils
t_bool	prs_is_variable(char *c);
t_bool	prs_is_underbar(char *c);
t_bool	prs_is_possible_var_space(char *c);
t_bool	prs_is_possible_var_name(char *c);

// count utils
int	prs_count_pipe(char *ori_str);
size_t	prs_count_str_using_func(char *str,
		t_bool (*f)(char *), t_bool count_if_true);

// parse var
char	*prs_find_value_in_envp(char *str, char ***envp);
char	*prs_handle_possible_var_space(char **str, char ***envp, char *result);
char	*prs_process_variable(char **str,
			char **start, char ***envp, char *result);
char	*prs_parse_variable(char *str, char ***envp);

